# Eval (all team members)

Copy, paste, and complete the evaluation for every team member. You should do one for yourself, as a self-eval.

### Group Member's Name

Karina Larochelle

The answers for each question should be a number 1--5:

1 Never, 2 Rarely, 3 Sometimes, 4 Usually, 5 Always

#### Questions

1. Did your partner come to the scheduled meetings on time and ready to work?

Answer: 5


2. Did your partner read the lab handout before coming to the scheduled meetings, showing up wither with specific questions or ready to contribute?

Answer: 5


3. Did your partner cooperatively follow the pair programming model (rotating roles of driver and navigator, questioning and making observations as the navigator)?

Answer: 5


4. Did your partner contribute fully, fairly, and actively, to the best of his or her ability, to the completion of the lab?

Answer: 5


5. Was your partner's participation professional and cooperative overall?

Answer: 5

#### Open Feedback

Please write 2-3 sentences evaluation of the team member. What they did good and what they need to work on?

I enjoyed working with Karina and knew it would be a good experiance because we have worked together successfully in the past. Though the work was challenging she was always willing to attend help hours and put a lot of effort into completeing this assignment. We genrally work in the same room independtly and then come to together if we have questions or for shared parts of the assignment.



# Self Eval 

Copy, paste, and complete the evaluation for every team member. You should do one for yourself, as a self-eval.

### Group Member's Name

Ilanna Langton

The answers for each question should be a number 1--5:

1 Never, 2 Rarely, 3 Sometimes, 4 Usually, 5 Always

#### Questions

1. Did your partner come to the scheduled meetings on time and ready to work?

Answer: 5


2. Did your partner read the lab handout before coming to the scheduled meetings, showing up wither with specific questions or ready to contribute?

Answer: 5


3. Did your partner cooperatively follow the pair programming model (rotating roles of driver and navigator, questioning and making observations as the navigator)?

Answer: 5


4. Did your partner contribute fully, fairly, and actively, to the best of his or her ability, to the completion of the lab?

Answer: 5


5. Was your partner's participation professional and cooperative overall?

Answer: 5

#### Open Feedback

Please write 2-3 sentences evaluation of the team member. What they did good and what they need to work on?

This assignment was challenging for me and took some time to complete. I think I did a good job at getting extra help and putting in effort to learn and finish the lab. I wish I managed my time a little better because I think I could have completed it a day earlier.