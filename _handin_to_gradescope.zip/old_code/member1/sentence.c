//#include "../fio/fio.h" // Include the custom file input/output library
#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *file; 
    char filename[] = "unix_sentence.text"; 
    // Buffer to store each line of the file
    char *buffer = NULL;
    size_t buffer_size = 0;

    file = fopen(filename, "r");
    if (file == NULL) {
        fprintf(stderr, "Error: Unable to open file %s\n", filename);
        return 1;
    }

    while (getline(&buffer, &buffer_size, file) != -1) { 
        // Print the line to the standard output
        fputs(buffer, stdout); 
    }

    free(buffer); // Free dynamically allocated buffer
    fclose(file); // Close the file

    return 0;
}