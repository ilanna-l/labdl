//#include "../fio/fio.h" // Include the custom file input/output library
#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *file; 
    char filename[] = "unix_sentence.text"; 
    // Buffer to store each line of the file
    char buffer[1024]; 

    file = fopen(filename, "r"); 

    while (fgets(buffer, sizeof(buffer), file) != NULL) { 
        // Print the line to the standard output
        fputs(buffer, stdout); 
    }

    fclose(file); // Close the file

    return 0;
}