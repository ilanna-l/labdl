#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void lowercase(const char* input, char* output) {
    // convert each character to lowercase
    for (size_t i = 0; i < strlen(input) + 1; i++) {
        output[i] = tolower(input[i]);
    }
}

int main() {
    // creates a 1024 byte buffer to store data
    char buffer[1024];
    // creates a 1024 byte buffer to store the lowercase version of the data
    char lowercaseBuffer[1024];

    // Read data from stdin and write it to stdout (standard output)
    while (fgets(buffer, sizeof(buffer), stdin) != NULL) {
        // pass data from the buffer to the lowercase function to convert it to lowercase
        lowercase(buffer, lowercaseBuffer);
        fputs(lowercaseBuffer, stdout);
    }

    return 0;
}
