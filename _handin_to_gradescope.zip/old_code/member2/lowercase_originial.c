#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char* lowercase(const char* input) {
    // calculate the maximum possible len of the result
    size_t maxLen = strlen(input) + 1;

    char* result = (char*)malloc(maxLen); // allocate memory for the result
    if (result == NULL) {
        fprintf(stderr, "ERROR: memory allocation failed in lowercase.\n");
        exit(1);
    }

    // convert each character to lowercase
    for (size_t i = 0; i < maxLen; i++) {
        result[i] = tolower(input[i]);
    }

    return result;
}

int main() {
    // creates a 1024 byte buffer to store data, will this be enough memory to store data?
    char buffer[1024];

    // Read data from stdin and write it to stdout (standard output)
    while (fgets(buffer, sizeof(buffer), stdin) != NULL) {
        // pass data from the buffer to the lowercase function to convert it to lowercase
        char* lowercaseResult = lowercase(buffer);
        fputs(lowercaseResult, stdout);
        free(lowercaseResult); // free the memory allocated for lowercaseResult
    }

    return 0;
}
